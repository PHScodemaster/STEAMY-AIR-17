# 2017SteamAirShip
This is the set of files that Team 4949 is sharing as they work on the code for their 2017 robot.

Wheel calculations. You can thank team 45 and team 1114 for this tutorial on the Mecanum Wheels - http://files.andymark.com/2008CON-Omni-Baker-McKenzie.pdf 
